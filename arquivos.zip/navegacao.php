    <nav>

    <ul>

        <li><a href="index.php">Quem Somos</a></li>
        <li>
            
            <a href="#">Serviços</a>
            <ul>
          <li><a href="index.php">home</a></li>
          <li><a href="cadastro.php">cadastro</a></li>
          <li><a href="orçamento.php">Orçamento</a></li>
          <li><a href="venda.php">Venda</a></li>
          <li><a href="login.php">login</a></li>
            </ul>
        </li>
    </ul>
</nav>